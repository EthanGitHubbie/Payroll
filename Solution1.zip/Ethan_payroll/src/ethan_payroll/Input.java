package ethan_payroll;

import java.util.Scanner;

public class Input {

    public void payCalc() {
        Scanner scan = new Scanner(System.in);
        Shift1 one = new Shift1();
        Shift2 two = new Shift2();
        Shift3 three = new Shift3();
        System.out.println("""
                           Please select your assigned shift: 
                           1 - Morning Shift
                           2 - Day Shift
                           3 - Night Shift""");
        int shifChoice = scan.nextInt();
        switch (shifChoice) {
            case 1 ->
                one.payCalc();
            case 2 ->
                two.payCalc();
            case 3 ->
                three.payCalc();
            default ->
                System.out.println("Invalid input");
        }
    }
}
