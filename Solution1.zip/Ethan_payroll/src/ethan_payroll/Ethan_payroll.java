package ethan_payroll;


import java.util.*;

public class Ethan_payroll {
   
    public static void main(String[] args) {
           Input in = new Input();
           in.payCalc();
    }

}
