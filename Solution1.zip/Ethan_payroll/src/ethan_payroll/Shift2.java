package ethan_payroll;

import java.util.Scanner;

public class Shift2 extends Shift1 {
int hours;
    public void payCalc() {
        Scanner scan = new Scanner(System.in);
        Shift2 shif = new Shift2();
        System.out.println("How many hours do you work in a week?");
        hours = scan.nextInt();

        if (hours <= 40 && hours != 0) {
            int weekPay = hours * 70;
            shif.retire(weekPay, hours);
        } else if (hours > 40 && hours != 0) {
            int overTime = hours - 40;
            int calcOver = overTime * (int) (70 * 1.5);
            int weekOver = calcOver + (40 * 70);
            shif.retireOver(weekOver, hours, calcOver);
        } else {
            System.out.println("Invalid input");
        }
    }

    public void retire(int weekPay, int hours) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Do you wish to sign up for the retirement plan? (yes/no)");
        String choice = scan.nextLine();
        if ("yes".equalsIgnoreCase(choice)) {
            double retire = (int) (weekPay * 0.05);
            double retPay = weekPay - retire;
            System.out.println();
            System.out.println("Payroll:");
            System.out.println("----------");
            System.out.println("Hours Worked: " + hours);
            System.out.println("Shift: Day");
            System.out.println("Hourly Pay Rate: R70.00");
            System.out.println("Regular Pay: R" + weekPay);
            System.out.println("Overtime Pay: R0.00");
            System.out.println("Total of Regular and Overtime: R" + weekPay);
            System.out.println("Retirment Deduction: R" + retire);
            System.out.println("Net Pay: R" + retPay);
        } else if ("no".equalsIgnoreCase(choice)) {
            System.out.println();
            System.out.println("Payroll:");
            System.out.println("----------");
            System.out.println("Hours Worked: " + hours);
            System.out.println("Shift: Day");
            System.out.println("Hourly Pay Rate: R70.00");
            System.out.println("Regular Pay: R" + weekPay);
            System.out.println("Overtime Pay: R0.00");
            System.out.println("Total of Regular and Overtime: R" + weekPay);
            System.out.println("Retirment Deduction: R0.00");
            System.out.println("Net Pay: R" + weekPay);
        } else {
            System.out.println("Invalid Option");
        }
    }

    public void retireOver(int weekOver, int hours, int calcOver) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Do you wish to sign up for the retirement plan? (yes/no)");
        String choice = scan.nextLine();
        if ("yes".equalsIgnoreCase(choice)) {
            double retire = (int) (weekOver * 0.05);
            double retPay = weekOver - retire;
            System.out.println();
            System.out.println("Payroll:");
            System.out.println("----------");
            System.out.println("Hours Worked: " + hours);
            System.out.println("Shift: Day");
            System.out.println("Hourly Pay Rate: R70.00");
            System.out.println("Regular Pay: R" + (40 * 70));
            System.out.println("Overtime Pay: R" + calcOver);
            System.out.println("Total of Regular and Overtime: R" + weekOver);
            System.out.println("Retirment Deduction: R" + retire);
            System.out.println("Net Pay: R" + retPay);
        } else if ("no".equalsIgnoreCase(choice)) {
            System.out.println();
            System.out.println("Payroll:");
            System.out.println("----------");
            System.out.println("Hours Worked: " + hours);
            System.out.println("Shift: Day");
            System.out.println("Hourly Pay Rate: R70.00");
            System.out.println("Regular Pay: R" + (40 * 70));
            System.out.println("Overtime Pay: R" + calcOver);
            System.out.println("Total of Regular and Overtime: R" + weekOver);
            System.out.println("Retirment Deduction: R0.00");
            System.out.println("Net Pay: R" + weekOver);
        } else {
            System.out.println("Invalid Option");
        }
    }
}
