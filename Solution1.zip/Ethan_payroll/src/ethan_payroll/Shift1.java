package ethan_payroll;

import java.util.Scanner;
import java.io.*;

public class Shift1 extends Input {
    
    public void payCalc() {
     
           Scanner scan = new Scanner(System.in);
           System.out.println("How many hours do you work in a week?");
           int hours = scan.nextInt();
        if (hours <= 40 && hours != 0) {
            int weekPay = hours * 50;

            System.out.println();
            System.out.println("Payroll:");
            System.out.println("----------");
            System.out.println("Hours Worked: " + hours);
            System.out.println("Shift: Morning");
            System.out.println("Hourly Pay Rate: R50.00");
            System.out.println("Regular Pay: R" + weekPay);
            System.out.println("Overtime Pay: R0.00");
            System.out.println("Total of Regular and Overtime: R" + weekPay);
            System.out.println("Retirment Deduction: R0.00");
            System.out.println("Net Pay: R" + weekPay);
        } else if (hours > 40 && hours != 0) {
            int overTime = hours - 40;
            int calcOver = overTime * (int) (50 * 1.5);
            int weekOver = calcOver + (40 * 50);
            System.out.println();
            System.out.println("Payroll:");
            System.out.println("----------");
            System.out.println("Hours Worked: " + hours);
            System.out.println("Shift: Morning");
            System.out.println("Hourly Pay Rate: R50.00");
            System.out.println("Regular Pay: R" + (40 * 50));
            System.out.println("Overtime Pay: R" + calcOver);
            System.out.println("Total of Regular and Overtime: R" + weekOver);
            System.out.println("Retirment Deduction: R0.00");
            System.out.println("Net Pay: R" + weekOver);
        } else {
            System.out.println("Invalid input");
        }
                
    }
    public void write(int hours){
        try{
            RandomAccessFile file = new RandomAccessFile("Hours.txt", "rw");
            file.seek(file.length());
            file.writeBytes("Hours Worked: " + hours);
            file.close();
        }catch(IOException e){
            System.out.println("Error");
        }
    }
}
