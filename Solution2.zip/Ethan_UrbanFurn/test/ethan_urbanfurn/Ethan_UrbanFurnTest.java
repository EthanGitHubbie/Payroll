package ethan_urbanfurn;

//import org.junit.jupiter.api.Test;
import org.junit.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Ethan_UrbanFurnTest {

    public Ethan_UrbanFurnTest() {
    }

    @Test
    public void testMain() {
        int shift1, regHours, overHours, rate, overRate, over;

        regHours = 40;
        overHours = 70;
        rate = 50;

        int expResult1A = 2000;
        shift1 = (regHours * rate);

        assertEquals(expResult1A, shift1);
        System.out.println("Shift 1\n - Hours: " + regHours + "\n - Regular Pay: R" + shift1 + "\n - Net Pay: R" + shift1);

        over = overHours - regHours;
        overRate = over * (int) (rate * 1.5);

        int expResult1B = 4250;
        shift1 = (expResult1A + overRate);

        assertEquals(expResult1B, shift1);
        System.out.println("Shift 1\n - Hours: " + overHours + "\n - Overtime Pay: R" + overRate + "\n - Net Pay: R" + shift1);

        int shift2;
        regHours = 40;
        overHours = 70;
        rate = 70;
        
        int expResult2A = 2800;

        shift2 = (regHours * rate);
        assertEquals(expResult2A, shift2);
        System.out.println("Shift 2\n - Hours: " + regHours + "\n - Regular Pay: R" + shift2 + "\n - Net Pay without Ret: R" + shift2);

        over = overHours - regHours;
        overRate = over * (int) (rate * 1.5);
        int expResult2B = 5950;
        shift2 = (expResult2A + overRate);
        assertEquals(expResult2B, shift2);
        System.out.println("Shift 2\n - Hours: " + overHours + "\n - Overtime Pay: R" + overRate + "\n - Net Pay without Ret: R" + shift2);
        
        int shift3;
        regHours = 40;
        overHours = 70;
        rate = 90;
        
        int expResult3A = 3600;

        shift3 = (regHours * rate);
        
        assertEquals(expResult3A, shift3);
        System.out.println("Shift 3\n - Hours: " + regHours + "\n - Regular Pay: R" + shift3 + "\n - Net Pay without Ret: R" + shift3);

        over = overHours - regHours;
        overRate = over * (int) (rate * 1.5);
        int expResult3B = 7650;
        shift3 = (expResult3A + overRate);
        assertEquals(expResult3B, shift3);
        System.out.println("Shift 3\n - Hours: " + overHours + "\n - Overtime Pay: R" + overRate + "\n - Net Pay without Ret: R" + shift3);
    }

    @Test
    public void testRetire2() {
        int shift2,regHours,rate;
        regHours = 40;
        rate = 70;
        double retPlan;
        
        int expResult2A = 2800;

        shift2 = (regHours * rate);
        retPlan = (shift2 *0.05);
        double retShift2 = shift2 - retPlan;
        assertEquals(expResult2A, shift2);
        
        System.out.println("""
                            Regular Shift 2:
                            - Without Retirement: R0.00
                            - With Retirement: R""" + retPlan + "\n- Net Pay with Ret: R" + retShift2);
    }

    @Test
    public void testRetireOver2() {
        int shift2,regHours,rate,overHours,overRate,over;
        regHours = 40;
        rate = 70;
        overHours = 70;
        double retPlan;
        int expResult2A = 2800;
        
        over = overHours - regHours;
        overRate = over * (int) (rate * 1.5);
        int expResult2B = 5950;
        shift2 = (expResult2A + overRate);
        retPlan = (shift2 *0.05);
        double retShift2 = shift2 - retPlan;
        assertEquals(expResult2B, shift2);
        
        System.out.println("""
                            Overtime Shift 2:
                            - Without Retirement: R0.00
                            - With Retirement: R""" + retPlan + "\n- Net Pay with Ret: R" + retShift2);
    }

    @Test
    public void testRetire3() {
        int shift3,regHours,rate;
        regHours = 40;
        rate = 90;
        double retPlan;
        
        int expResult3A = 3600;

        shift3 = (regHours * rate);
        retPlan = (shift3 *0.05);
        double retShift3 = shift3 - retPlan;
        assertEquals(expResult3A, shift3);
        
        System.out.println("""
                            Regular Shift 3:
                            - Without Retirement: R0.00
                            - With Retirement: R""" + retPlan + "\n- Net Pay with Ret: R" + retShift3);
    }

    @Test
    public void testRetireOver3() {
        int shift3,regHours,rate,overHours,overRate,over;
        regHours = 40;
        rate = 90;
        overHours = 70;
        double retPlan;
        
        int expResult3A = 3600;
        
        over = overHours - regHours;
        overRate = over * (int) (rate * 1.5);
        int expResult3B = 7650;
        shift3 = (expResult3A + overRate);
        retPlan = (shift3 *0.05);
        double retShift3 = shift3 - retPlan;
        assertEquals(expResult3B, shift3);
        
        System.out.println("""
                            Overtime Shift 3:
                            - Without Retirement: R0.00
                            - With Retirement: R""" + retPlan + "\n- Net Pay with Ret: R" + retShift3);
    }

}
