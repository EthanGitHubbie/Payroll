package ethan_urbanfurn;

import java.util.Scanner;
import java.io.*;
import java.text.DecimalFormat;

public class Ethan_UrbanFurn {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        Ethan_UrbanFurn plan = new Ethan_UrbanFurn();
        
        
        int hours;
        double hourly1 = 50;
        double hourly2 = 70;
        double hourly3 = 90;
        
        System.out.println("""
                           Please select your assigned shift: 
                           1 - Morning Shift
                           2 - Day Shift
                           3 - Night Shift""");
        int shifChoice = Integer.parseInt(scan.nextLine());
        
        switch (shifChoice) {
            
            case 1 -> {
                System.out.println("How many hours do you work in a week?");
                hours = scan.nextInt();
                try {
                    String content = ("Hours Worked: " + hours + "\n");
                    File fil = new File("C:\\Users\\ETHAN.V\\Documents\\NetBeansProjects\\Ethan_UrbanFurn\\Hours.txt");
                    FileWriter fw = new FileWriter((fil.getAbsoluteFile()), true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    bw.write(content);
                    bw.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (hours <= 40 && hours !=0) {
                    int weekPay = hours * 50;
                    System.out.println();
                    System.out.println("Payroll:");
                    System.out.println("----------");
                    System.out.println("Hours Worked: " + hours);
                    System.out.println("Shift: Morning");
                    System.out.println("Hourly Pay Rate: R" + hourly1);
                    System.out.println("Regular Pay: R" + weekPay);
                    System.out.println("Overtime Pay: R0.00");
                    System.out.println("Total of Regular and Overtime: R" + weekPay);
                    System.out.println("Retirment Deduction: R0.00");
                    System.out.println("Net Pay: R" + weekPay);
                } else if (hours > 40 && hours !=0) {
                    int overTime = hours - 40;
                    int calcOver = overTime * (int) (50 * 1.5);
                    float weekOver = calcOver + (40 * 50);
                    System.out.println();
                    System.out.println("Payroll:");
                    System.out.println("----------");
                    System.out.println("Hours Worked: " + hours);
                    System.out.println("Shift: Morning");
                    System.out.println("Hourly Pay Rate: R" + hourly1);
                    System.out.println("Regular Pay: R" + (40 * 50));
                    System.out.println("Overtime Pay: R" + calcOver);
                    System.out.println("Total of Regular and Overtime: R" + weekOver);
                    System.out.println("Retirment Deduction: R0.00");
                    System.out.println("Net Pay: R" + weekOver);
                } else {
                    System.out.println("Invalid input");
                }
            }

            case 2 -> {
                System.out.println("How many hours do you work in a week?");
                hours = scan.nextInt();
                try {
                    String content = ("Hours Worked: " + hours + "\n");
                    File fil = new File("C:\\Users\\ETHAN.V\\Documents\\NetBeansProjects\\Ethan_UrbanFurn\\Hours.txt");
                    FileWriter fw = new FileWriter((fil.getAbsoluteFile()), true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    bw.write(content);
                    bw.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (hours <= 40 && hours !=0) {
                    int weekPay = hours * 70;
                    plan.retire2(weekPay, hours, hourly2);
                } else if (hours > 40 && hours !=0) {
                    int overTime = hours - 40;
                    double calcOver = overTime *(70 * 1.5);
                    double weekOver = calcOver + (40 * 70);
                    plan.retireOver2(weekOver, hours, calcOver, hourly2);
                } else {
                    System.out.println("Invalid input");
                }
            }

            case 3 -> {
                System.out.println("How many hours do you work in a week?");
                hours = scan.nextInt();
                try {
                    String content = ("Hours Worked: " + hours + "\n");
                    File fil = new File("C:\\Users\\ETHAN.V\\Documents\\NetBeansProjects\\Ethan_UrbanFurn\\Hours.txt");
                    FileWriter fw = new FileWriter((fil.getAbsoluteFile()), true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    bw.write(content);
                    bw.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (hours <= 40 && hours !=0) {
                    int weekPay = hours * 90;
                    plan.retire3(weekPay, hours, hourly3);
                } else if (hours > 40 && hours !=0) {
                    int overTime = hours - 40;
                    double calcOver = overTime * (90 * 1.5);
                    double weekOver = calcOver + (40 * 90);
                    plan.retireOver3(weekOver, hours, calcOver, hourly3);
                } else {
                    System.out.println("Invalid input");
                }
            }
            default ->
                System.out.println("Invalid input");
        }
        
    }

    public void retire2(float weekPay, int hours, double hourly2) {
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Do you wish to sign up for the retirement plan? (yes/no)");
        String choice = scan.nextLine();
        if ("yes".equalsIgnoreCase(choice)) {
            double retire = (weekPay * 0.05);
            double retPay = weekPay - retire;
            System.out.println();
            System.out.println("Payroll:");
            System.out.println("----------");
            System.out.println("Hours Worked: " + hours);
            System.out.println("Shift: Day");
            System.out.println("Hourly Pay Rate: R" + hourly2);
            System.out.println("Regular Pay: R" + weekPay);
            System.out.println("Overtime Pay: R0.00");
            System.out.printf("Total of Regular and Overtime: R%.2f",weekPay);
            System.out.printf("\nRetirment Deduction: R%.2f",retire);
            System.out.printf("\nNet Pay: R%.2f",retPay);
            System.out.println();
        } else if ("no".equalsIgnoreCase(choice)) {
            System.out.println();
            System.out.println("Payroll:");
            System.out.println("----------");
            System.out.println("Hours Worked: " + hours);
            System.out.println("Shift: Day");
            System.out.println("Hourly Pay Rate: R" + hourly2);
            System.out.println("Regular Pay: R" + weekPay);
            System.out.println("Overtime Pay: R0.00");
            System.out.println("Total of Regular and Overtime: R" + weekPay);
            System.out.println("Retirment Deduction: R0.00");
            System.out.println("Net Pay: R" + weekPay);
        } else {
            System.out.println("Invalid Option");
        }
    }

    public void retireOver2(double weekOver, int hours, double calcOver, double hourly2) {
        Scanner scan = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat();
        df.setMaximumFractionDigits(2);
        System.out.println("Do you wish to sign up for the retirement plan? (yes/no)");
        String choice = scan.nextLine();
        if ("yes".equalsIgnoreCase(choice)) {
            double retire = (0.05 * weekOver);
            double retPay = weekOver - retire;
            System.out.println();
            System.out.println("Payroll:");
            System.out.println("----------");
            System.out.println("Hours Worked: " + hours);
            System.out.println("Shift: Day");
            System.out.println("Hourly Pay Rate: R" + hourly2);
            System.out.println("Regular Pay: R" + (40 * 70));
            System.out.println("Overtime Pay: R" + calcOver);
            System.out.printf("Total of Regular and Overtime: R%.2f",weekOver);
            System.out.printf("\nRetirment Deduction: R%.2f",retire);
            System.out.printf("\nNet Pay: R%.2f",retPay);
            System.out.println();
        } else if ("no".equalsIgnoreCase(choice)) {
            System.out.println();
            System.out.println("Payroll:");
            System.out.println("----------");
            System.out.println("Hours Worked: " + hours);
            System.out.println("Shift: Day");
            System.out.println("Hourly Pay Rate: R" + hourly2);
            System.out.println("Regular Pay: R" + (40 * 70));
            System.out.println("Overtime Pay: R" + calcOver);
            System.out.println("Total of Regular and Overtime: R" + weekOver);
            System.out.println("Retirment Deduction: R0.00");
            System.out.println("Net Pay: R" + weekOver);
        } else {
            System.out.println("Invalid Option");
        }
    }

    public void retire3(float weekPay, int hours, double hourly3) {
        Scanner scan = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat();
        df.setMaximumFractionDigits(2);
        System.out.println("Do you wish to sign up for the retirement plan? (yes/no)");
        String choice = scan.nextLine();
        if ("yes".equalsIgnoreCase(choice)) {
            double retire = (0.05 * weekPay);
            double retPay = weekPay - retire;
            System.out.println();
            System.out.println("Payroll:");
            System.out.println("----------");
            System.out.println("Hours Worked: " + hours);
            System.out.println("Shift: Night");
            System.out.println("Hourly Pay Rate: R" + hourly3);
            System.out.println("Regular Pay: R" + weekPay);
            System.out.println("Overtime Pay: R0.00");
            System.out.printf("Total of Regular and Overtime: R%.2f",weekPay);
            System.out.printf("\nRetirment Deduction: R%.2f",retire);
            System.out.printf("\nNet Pay: R%.2f",retPay);
            System.out.println();
        } else if ("no".equalsIgnoreCase(choice)) {
            System.out.println();
            System.out.println("Payroll:");
            System.out.println("----------");
            System.out.println("Hours Worked: " + hours);
            System.out.println("Shift: Night");
            System.out.println("Hourly Pay Rate: R" + hourly3);
            System.out.println("Regular Pay: R" + weekPay);
            System.out.println("Overtime Pay: R0.00");
            System.out.println("Total of Regular and Overtime: R" + weekPay);
            System.out.println("Retirment Deduction: R0.00");
            System.out.println("Net Pay: R" + weekPay);
        } else {
            System.out.println("Invalid Option");
        }
    }

    public void retireOver3(double weekOver, int hours, double calcOver, double hourly3) {
        Scanner scan = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat();
        df.setMaximumFractionDigits(4);
        System.out.println("Do you wish to sign up for the retirement plan? (yes/no)");
        String choice = scan.nextLine();
        if ("yes".equalsIgnoreCase(choice)) {
            double retire = (0.05 * weekOver);
            double retPay = weekOver - retire;
            System.out.println();
            System.out.println("Payroll:");
            System.out.println("----------");
            System.out.println("Hours Worked: " + hours);
            System.out.println("Shift: Night");
            System.out.println("Hourly Pay Rate: R" + hourly3);
            System.out.println("Regular Pay: R" + (40 * 90));
            System.out.println("Overtime Pay: R" + calcOver);
            System.out.printf("Total of Regular and Overtime: R%.2f",weekOver);
            System.out.printf("\nRetirment Deduction: R%.2f",retire);
            System.out.printf("\nNet Pay: R%.2f",retPay);
            System.out.println();
        } else if ("no".equalsIgnoreCase(choice)) {
            System.out.println();
            System.out.println("Payroll:");
            System.out.println("----------");
            System.out.println("Hours Worked: " + hours);
            System.out.println("Shift: Night");
            System.out.println("Hourly Pay Rate: R" + hourly3);
            System.out.println("Regular Pay: R" + (40 * 90));
            System.out.println("Overtime Pay: R" + calcOver);
            System.out.println("Total of Regular and Overtime: R" + weekOver);
            System.out.println("Retirment Deduction: R0.00");
            System.out.println("Net Pay: R" + weekOver);
        } else {
            System.out.println("Invalid Option");
        }
    }

}
